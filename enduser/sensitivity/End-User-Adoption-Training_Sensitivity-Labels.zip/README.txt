Readme.txt for Internal downloads of End User Training - Microsoft Information Protection Sensitivy Lables

The following training is provided for End Users to help educate, train, and learn how to apply data labels to documents. Please note that 'Munson's Pickles and Preserves Farm' is a fictitious company named and angle brackets "<>" with RED text enable the training to be updated for deployment, adoption and education for each industry or regulatory compliance.

This documentation will be updated on a quarterly basis to include new features or solutions released from Microsoft 365.